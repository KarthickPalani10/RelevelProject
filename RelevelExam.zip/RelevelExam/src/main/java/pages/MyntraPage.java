package pages;//import java.util.*;

import base.PredefinedActions;
import constants.ConstantPaths;
import utils.PropertyReading;

import java.util.ArrayList;

public class MyntraPage extends PredefinedActions {
    private static MyntraPage MyntraPage;
    private final PropertyReading myntraPageProp;

    private MyntraPage() {
        myntraPageProp = new PropertyReading(ConstantPaths.PROP_PATH + "MyntraPageProp.properties");
    }

    public static MyntraPage getMyntraPage() {
        if (MyntraPage == null)
            MyntraPage = new MyntraPage();
        return MyntraPage;
    }

    public void hoverOnMen() {
        hoverOnElement(getElement(myntraPageProp.getValue("hoverOnMen"), true), true);
    }

    public void clickOnTshirt() {
        clickOnElement(myntraPageProp.getValue("tshirtOption"), true);
    }

    public void clickOnMoreOption() {
        clickOnElement(myntraPageProp.getValue("moreOption"), true);
    }

    public ArrayList<Integer> selectHrxAndHereAndNow() {
        ArrayList<Integer> arrayList = new ArrayList<>();
        enterText(getElement(myntraPageProp.getValue("inputBrand"), true), "hrx");
        clickOnElement(myntraPageProp.getValue("hrx"), true);
        arrayList.add(Integer.parseInt(getElementText(getElement(myntraPageProp.getValue("hrxCount"), true)).
                replace("(","").replace(")","")));
        clearElementField(myntraPageProp.getValue("inputBrand"), true);
        enterText(getElement(myntraPageProp.getValue("inputBrand"), true), "here");
        arrayList.add(Integer.parseInt(getElementText(getElement(myntraPageProp.getValue("hereCount"), true)).
                replace("(","").replace(")","")));
        clickOnElement(myntraPageProp.getValue("herenow"), true);
        return arrayList;
    }

    public void closeDialogueBox() {
        clickOnElement(myntraPageProp.getValue("closeDialoge"), true);
    }
    public int getTotalCount(){
        return Integer.parseInt(getElementText(getElement(myntraPageProp.getValue("totalItem"),true)).replace("\s","")
                .replace("items","").replace("-",""));

    }

    public boolean isTitleContainsString(){
        return getWebpageUrl().contains("men-tshirts?f=Brand%3AHERE%26NOW%2CHRX by Hrithik Roshan");

    }
}
