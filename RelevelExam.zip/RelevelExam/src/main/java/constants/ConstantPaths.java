package constants;

public class ConstantPaths {
    public static final String PROP_PATH = "src/main/resources/Configs/";
}
