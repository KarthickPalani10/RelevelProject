package testscripts;//import java.util.*;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.MyntraPage;

import java.util.ArrayList;

public class MyntraTest extends TestBase {
    @Test
    public void myntraTest(){

        MyntraPage myntraPage = MyntraPage.getMyntraPage();
        myntraPage.hoverOnMen();
        myntraPage.clickOnTshirt();
        myntraPage.clickOnMoreOption();
        ArrayList<Integer> countsList = myntraPage.selectHrxAndHereAndNow();
        System.out.println(countsList.get(0) + " is count of HRX & "+ countsList.get(1)+" is count of Here & Now Tshirt");
        myntraPage.closeDialogueBox();
        System.out.println(myntraPage.getTotalCount());
        int countTotal = myntraPage.getTotalCount();
        System.out.println("Total count is : "+ countTotal);
        Assert.assertEquals(countsList.get(0)+countsList.get(1),countTotal);
        boolean isTitlePresent = myntraPage.isTitleContainsString();
        Assert.assertTrue(isTitlePresent);


    }

}
